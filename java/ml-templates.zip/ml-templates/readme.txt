# ***************************************************************************
# Copyright (c) 2013 SAP AG or an SAP affiliate company. All rights reserved.
# ***************************************************************************
The files in this directory are templates used to generate SQL synchronization 
scripts.